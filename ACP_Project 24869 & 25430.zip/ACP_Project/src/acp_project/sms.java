/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acp_project;

/**
 *
 * @author pc
 */

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

public class sms {
    
    private static int otp;
    
    public void setotp(int OTP)
    {
        this.otp=OTP;
    }
    
    public int getotp()
    {
        return otp;
    }

    public void run(){
         Twilio.init("AC8dfcbcbd6feb147becddc59782844196", "34b9628e3e5b6508578f179cd6d262f7");
        Message message = Message.creator(
                new com.twilio.type.PhoneNumber("+923213258464"),
                new com.twilio.type.PhoneNumber("+15104056118"),
                "Your OTP is:"+getotp())
            .create();
    }
       
}
