/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acp_project;

import com.fazecast.jSerialComm.*;
import java.util.Scanner;

import com.fazecast.jSerialComm.SerialPort;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class SerialData {
    private SerialPort[] ports;
    private String[] portNames;
    private SerialPort selectedPort;
    private Scanner redSerial;
    
    public SerialData(){
        ports = SerialPort.getCommPorts();
        
        
    }
    
    public void portConnect(){
        this.selectedPort= ports[0] ;
        selectedPort.openPort();
        selectedPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING,0, 0);
        redSerial = new Scanner(selectedPort.getInputStream());
    }
    public Scanner getScanner(){
        return redSerial;
    }
    
    public String getData(){
        return redSerial.nextLine();
    }
    public SerialPort[] getPorts(){
        return this.ports;
      }
    
    public SerialPort getSelectedPort(){
        return selectedPort;
    }
}