/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acp_project;

/**
 *
 * @author pc
 */
public class user_data {
    
    private static String Name;
    
    public void setName(String name)
    {
        this.Name=name;
    }
    
    public String getName()
    {
        return Name;
    }
    
     private static int otp;
    
    public void setotp(int OTP)
    {
        this.otp = OTP;
    }
    
    public int getotp()
    {
        return otp;
    }
    
}
